1) Start server using python3 (python3 server.py [0,1])
	0 disables 3-fold cross validation
	1 enables 3-fold cross validation (and prints estimated accuracy)

2)Open browser (if possible Mozilla Firefox) and go to http://localhost:5000

3)Enjoy! :D
