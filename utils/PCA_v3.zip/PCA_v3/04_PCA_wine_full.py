import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from matplotlib.mlab import PCA as mlabPCA
from sklearn import preprocessing


def generateFile(label,Y,dataFile):
    att=['Y1','Y2']+label
    f=open('pca.csv','w')
    fin=open(dataFile)
    for i in range(len(att)-1):
        print(att[i],',',end='',file=f)
    print(att[-1],file=f)
    for i in range(len(Y)-1):
        s=fin.readline()
        print(Y[i][0],',',Y[i][1],',',s,file=f)   
    f.close()
    

#read data from a CSV file, you can choose different delimiters
att=['Class label', 'Alcohol', 'Malic acid','Ash','Alcalinity of ash','Magnesium',
     'Total phenols','Flavanoids','Nonflavanoid phenols','Proanthocyanins',
     'Color intensity','Hue','OD280/OD315 of diluted wines','Proline']
data = pd.io.parsers.read_csv(
     'wine.data.csv', 
     header=None
    )
data.columns=att
#print(data.head())
d=data.values[:,1:]#we exclude the first column

d_pca = mlabPCA(d)  
generateFile(att,d_pca.Y,'wine.data.csv')





plt.plot(d_pca.Y[:,0],d_pca.Y[:,1], 'o', markersize=3, color='blue', alpha=0.5, label='PCA transformed data in the new 2D space')    
plt.xlabel('Y1')
plt.ylabel('Y2')
plt.xlim([-4,4])
plt.ylim([-4,4])
plt.legend()
plt.title('Transformed data from matplotlib.mlab.PCA()')

plt.show()

s = 30
plt.scatter(d_pca.Y[0:59, 0], d_pca.Y[0:59, 1],
            color='red',s=s, lw=0, label='Cluster 1')
plt.scatter(d_pca.Y[59:130, 0], d_pca.Y[59:130, 1],
            color='green',s=s, lw=0, label='Cluster 2')
plt.scatter(d_pca.Y[130:178, 0], d_pca.Y[130:178, 1],
            color='blue',s=s, lw=0, label='Cluster 3')
plt.xlabel('Y1')
plt.ylabel('Y2')
plt.legend()
plt.title('Transformed data from matplotlib.mlab.PCA()')

plt.show()



##d_cov=np.cov(d.T)
##for i in range(len(d_cov)):
##    print('Variance original data not scaled axis n'+str(i),d_cov[i][i])

#normalize the data with StandardScaler
std_scale = preprocessing.StandardScaler().fit(d)
d_std = std_scale.transform(d)

#compute the covariance matrix
d_cov=np.cov(d_std.T)

#compute and sort eigenvalues
d_val,d_vec= np.linalg.eig(d_cov)
d_val.sort()


print('Cumulated variance of the first two PCA components:',
      (d_val[-1]+d_val[-2])/sum(d_val))








