import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from matplotlib.mlab import PCA as mlabPCA
#read data from a CSV file, you can choose different delimiters
data=pd.io.parsers.read_csv('data.csv',
     delimiter=',',
     header=None,
     usecols=[0,1]
    )
data.columns=['X1','X2']
#pd.io.parsers.read_csv rturns a useful but complex type;
#to transform it in a numpy.array use .values
d=data.values

#used for x projections#############                                                                                   
zeros=[]       # [0,0,0,0,0,.....
n_tuples=d[:,0].size
for i in range(n_tuples):
    zeros.append(0)
##################################    
    
#plotting d on a 2D scatterplot
plt.plot(d[:,0],d[:,1],
         'o', markersize=7,
         color='blue',
         alpha=0.5,
         label='original data')
plt.xlabel('X1')
plt.ylabel('X2')
plt.xlim([-1,1]) 
plt.ylim([-1,1]) 
plt.legend()
plt.show()


#running mlabPCA that returns an object whose .Y is a numpy.array
# d_pca.Y[:,0] will contain values of first component (max variance)
# d_pca.Y[:,i] will contain values of ith component
d_pca = mlabPCA(d)
                       
#projecting new values on the first component
plt.plot(d_pca.Y[:,0],zeros, #zeros=[0,0,0,0,..]
         'o',
         markersize=7,
         color='green',
         alpha=0.5,
         label='PCA first component proj')
plt.xlabel('Y1')
plt.ylabel('Y2')
plt.xlim([-4,4])
plt.ylim([-4,4])
plt.legend()
plt.title('Transformed data projected on first component')
plt.show()
 


