import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from matplotlib.mlab import PCA as mlabPCA
from sklearn import preprocessing


#read data from a CSV file, you can choose different delimiters
att=['Class label', 'Alcohol', 'Malic acid','Ash','Alcalinity of ash','Magnesium','Total phenols','Flavanoids',
            'Nonflavanoid phenols','Proanthocyanins','Color intensity','Hue','OD280/OD315 of diluted wines','Proline']
data = pd.io.parsers.read_csv('scale.csv',
     delimiter=',',
     header=None,
     usecols=[0,1]
    )
data.columns=['Alcohol', 'Malic acid']
print(data.head())

d=data.values
cov_ori=np.cov(d.T)

std_scale = preprocessing.StandardScaler().fit(d)
df_std = std_scale.transform(d)
cov_std=np.cov(df_std.T)


minmax_scale = preprocessing.MinMaxScaler().fit(d)
df_minmax = minmax_scale.transform(d)
cov_mmx=np.cov(df_minmax.T)


def plot1():
    plt.figure(figsize=(8,6))
    plt.scatter(d.T[0], d.T[1],
            color='green', label='input scale', alpha=0.5)
    plt.scatter(df_std.T[0], df_std.T[1], color='red',
            label='Standardized mu=0 sigma=1', alpha=0.3)
    plt.scatter(df_minmax.T[0], df_minmax.T[1],
            color='blue', label='min-max scaled [min=0, max=1]', alpha=0.3)
    plt.title('Alcohol and Malic Acid content of the wine dataset')
    plt.xlabel('Alcohol')
    plt.ylabel('Malic Acid')
    plt.legend(loc='upper left')
    plt.grid()

    plt.tight_layout()
plot1()
plt.show()

print(40*'-','\nCovariance matrix original data:\n',cov_ori)
print(40*'-','\nCovariance matrix standardized:\n',cov_std)
print(40*'-','\nCovariance matrix minmax:\n',cov_mmx)



