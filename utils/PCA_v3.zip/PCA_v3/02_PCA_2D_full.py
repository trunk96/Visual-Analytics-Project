import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
from mpl_toolkits.mplot3d import proj3d
from matplotlib.mlab import PCA as mlabPCA
from sklearn import preprocessing
#read data from a CSV file, you can choose different delimiters
data=pd.io.parsers.read_csv('data.csv',
     delimiter=',',
     header=None,
     usecols=[0,1]
    )
data.columns=['X1','X2']
#pd.io.parsers.read_csv rturns a useful but complex type;
#to transform it in a numpy.ndarray use .values
d=data.values

#used for x projections#############                                                                                   
zeros=[]       # [0,0,0,0,0,.....
minusOnes=[] 
minusTwos=[]
minusThrees=[]
n_tuples=d[:,0].size
for i in range(n_tuples):
    zeros.append(0)
    minusOnes.append(-1)   # [-1,-1,-1,-1,-1,.....
    minusTwos.append(-2)   # [-2,-2,-2,-2,-2,..... 
    minusThrees.append(-3) # [-3,-3,-3,-3,-3,...
##################################    
    
#plotting d on a 2D scatterplot
plt.plot(d[:,0],d[:,1],
         'o', markersize=7,
         color='blue',
         alpha=0.5,
         label='original data')
plt.xlabel('X1')
plt.ylabel('X2')
plt.xlim([-1,1]) 
plt.ylim([-1,1]) 
plt.legend()
plt.show()


#running mlabPCA that returns an object whose .Y is a numpy.array
# d_pca.Y[:,0] will contain values of first component (max variance)
# d_pca.Y[:,i] will contain values of ith component
d_pca = mlabPCA(d)
                       
#projecting new values on the first component
plt.plot(d_pca.Y[:,0],zeros, #zeros=[0,0,0,0,..]
         'o',
         markersize=7,
         color='green',
         alpha=0.5,
         label='PCA first component proj')
plt.xlabel('projected_Y1_values')
plt.ylabel('Y2')
plt.xlim([-4,4])
plt.ylim([-4,4])
plt.legend()
plt.title('Transformed data projected on first component')
plt.show()


print(' run explanation() for detailed steps!!!')


def explanation():
    #plotting d on a 2D scatterplot
    plt.plot(d[:,0],d[:,1], 'o', markersize=7, color='blue', alpha=0.5, label='original data')
    plt.xlabel('X1')
    plt.ylabel('X2')
    plt.xlim([-1,1])
    plt.ylim([-1,1])
    plt.legend()
    plt.show()   

    #R2->R1 projecting on X1 axis
    plt.plot(d[:,0], zeros,'o', markersize=7, color='blue', alpha=0.5, label='original data X1 projection')
    plt.xlabel('X1')
    plt.ylabel('X2')
    plt.xlim([-1,1])
    plt.ylim([-1,1])
    plt.legend()
    plt.show()

    #R2->R1 projecting on X2 axis
    plt.plot(d[:,1],zeros, 'o', markersize=7, color='blue', alpha=0.5, label='original data X2 projection (axes are reverted for readability)')
    plt.xlabel('X2')
    plt.ylabel('X1')
    plt.xlim([-1,1])
    plt.ylim([-1,1])
    plt.legend()
    plt.show()


    #computing the mean on the 2 axes
    mean_x1 = np.mean(d[:,0])
    mean_x2 = np.mean(d[:,1])
    mean_vector = np.array([[mean_x1],[mean_x2]])

    print('Mean Vector:\n', mean_vector)


    #computing the covariance matrix
    cov_mat = np.cov(d.T)
    print('Covariance Matrix:\n', cov_mat)

    # eigenvectors and eigenvalues from the covariance matrix
    d_val, d_vec = np.linalg.eig(cov_mat)
    print('Eigenvectors:\n', d_vec.T)


    for i in range(len(d_val)):
        eigvec_cov = d_vec[:,i].reshape(1,2).T
        print('Eigenvalue {} from covariance matrix: {}'.format(i+1, d_val[i]))
        print(40 * '-')

    #plotting eigenvectors on the scatterplot
    plt.figure()
    plt.plot(mean_x1,mean_x2, 'o', markersize=7, color='red', alpha=0.5, label='(mu_x1,mu_x2)')
    plt.title('Eigenvectors')
    soa=[]
    factor=2 #reduce the eigenvector size
    for v in d_vec.T:
        soa.append([mean_x1,mean_x2, v[0]/factor, v[1]/factor])  
    X, Y, U, V = zip(*soa) #quiver data for printing arrows
    ax = plt.gca()
    ax.quiver(X, Y, U, V, angles='xy', scale_units='xy', scale=1)
    plt.plot(d[:,0],d[:,1], 'o', markersize=5, color='blue', alpha=0.5, label='original data')

    plt.xlabel('X1')
    plt.ylabel('X2')
    plt.xlim([-1,1])
    plt.ylim([-1,1])
    plt.legend()
    plt.show()
    
    d_pca = mlabPCA(d) #easier way ....
    
    plt.plot(d_pca.Y[:,0],d_pca.Y[:,1], 'o', markersize=3, color='blue', alpha=0.5, label='PCA transformed data in the new 2D space')    
    plt.xlabel('Y1')
    plt.ylabel('Y2')
    plt.xlim([-4,4])
    plt.ylim([-4,4])
    plt.legend()
    plt.title('Transformed data from matplotlib.mlab.PCA()')

    plt.show()


    plt.figure(figsize=(8,6))
    plt.plot(d_pca.Y[:,0],d_pca.Y[:,1], 'o', markersize=3, color='blue', alpha=0.5, label='PCA transformed data in the new 2D space')   
    plt.plot(d_pca.Y[:,0],zeros, 'o', markersize=7, color='green', alpha=0.5, label='PCA first component proj:  THE RESULT')
    plt.plot(d_pca.Y[:,1],minusOnes, 'o', markersize=7, color='red', alpha=0.5, label='PCA second component proj (moved at y=-1 and rotated for readability)')
    plt.plot(d[:,1],minusTwos, 'o', markersize=7, color='blue', alpha=0.5, label='Original X2 projection (moved at y=-2 and rotated for readability)')
    plt.plot(d[:,0],minusThrees, 'o', markersize=7, color='orange', alpha=0.5, label='Original X1 projection(moved at y=-3 for readability)')
    plt.xlabel('x')
    plt.ylabel('y')
    plt.xlim([-4,4])
    plt.ylim([-4,4])
    plt.legend()
    plt.title('Comparison')
    plt.show()

explanation()
